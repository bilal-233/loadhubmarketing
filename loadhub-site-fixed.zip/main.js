(function(){
var WA='16468956658',$=function(s,r){return(r||document).querySelector(s)},$$=function(s,r){return[].slice.call((r||document).querySelectorAll(s))};
function wa(t){return'https://wa.me/'+WA+'?text='+encodeURIComponent(t)}
/* theme */
var root=document.documentElement,tb=$('#theme');
function setT(t){root.setAttribute('data-theme',t);if(tb)tb.innerHTML='<svg class="i"><use href="#solid-'+(t=='dark'?'sun':'moon')+'"/></svg>';try{localStorage.setItem('lh-theme',t)}catch(e){}}
var st=null;try{st=localStorage.getItem('lh-theme')}catch(e){}
setT(st||(matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light'));
if(tb)tb.onclick=function(){setT(root.getAttribute('data-theme')=='dark'?'light':'dark')};
/* nav */
var bg=$('#burger'),nv=$('nav');if(bg)bg.onclick=function(){var o=nv.classList.toggle('open');bg.setAttribute('aria-expanded',o)};
$$('nav a').forEach(function(a){a.addEventListener('click',function(){if(nv)nv.classList.remove('open')})});
/* reveal + counters */
var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:.15});
$$('.rv').forEach(function(el,i){el.style.transitionDelay=(i%4)*90+'ms';io.observe(el)});
var co=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;var el=e.target,n=+el.dataset.n,c=0,step=Math.max(1,Math.ceil(n/40));var t=setInterval(function(){c=Math.min(n,c+step);el.textContent=c.toLocaleString('en-US')+(el.dataset.s||'');if(c>=n)clearInterval(t)},35);co.unobserve(el)})},{threshold:.6});
$$('[data-n]').forEach(function(el){co.observe(el)});
/* lead submit (Netlify Forms -> email) + WhatsApp */
function enc(o){return Object.keys(o).map(function(k){return encodeURIComponent(k)+'='+encodeURIComponent(o[k])}).join('&')}
var W3F=(window.LH_CONFIG&&window.LH_CONFIG.formKey)||'';
function send(d){if(!W3F||W3F.indexOf('PASTE')===0)return Promise.reject(new Error('no key'));var o={};Object.keys(d).forEach(function(k){if(k!=='form-name'&&k!=='bot-field')o[k]=d[k]});o.name=d.name||((d.first||'')+' '+(d.last||'')).trim();o.access_key=W3F;o.subject='New website lead: '+(d.service||'Contact');o.from_name='Loadhub Marketing website';if(d['bot-field'])o.botcheck=true;return fetch('https://api.web3forms.com/submit',{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify(o)}).then(function(r){return r.json()}).then(function(j){if(!j.success)throw new Error('failed');return j})}
function summary(d){var nm=d.name||((d.first||'')+' '+(d.last||'')).trim();return'Hello Loadhub Marketing, I am '+nm+'. Interested in: '+d.service+(d.dealtype?'. Deal type: '+d.dealtype:'')+'. Phone: '+(d.phone||'-')+'. Email: '+d.email+(d.message?'. Message: '+d.message:'')}
$$('form[data-lead]').forEach(function(f){
f.addEventListener('submit',function(ev){ev.preventDefault();
var d={};new FormData(f).forEach(function(v,k){d[k]=v});if(d['bot-field'])return;
var btn=$('button[type=submit]',f),old=btn.innerHTML;btn.disabled=true;btn.innerHTML='<svg class="i spin"><use href="#solid-spinner"/></svg> Sending';
var ok=$('.ok',f.parentNode),link=$('.wal',ok);link.href=wa(summary(d));
function done(){f.style.display='none';ok.style.display='block';ok.scrollIntoView({block:'center',behavior:'smooth'})}
send(d).then(function(r){done()}).catch(function(){$('.err',ok).style.display='block';done()});
})});
/* tabs */
var tabs=$$('.tab');if(tabs.length){var sel=function(id){tabs.forEach(function(t){t.setAttribute('aria-selected',t.dataset.tab==id)});$$('.panel').forEach(function(p){p.classList.toggle('on',p.id==id)})};
tabs.forEach(function(t){t.onclick=function(){sel(t.dataset.tab);try{history.replaceState(null,'','#'+t.dataset.tab)}catch(e){}}});
var fh=function(){var h=location.hash.slice(1);var pn=h&&document.querySelector('.panel[id="'+h+'"]');if(pn){sel(h);pn.scrollIntoView({behavior:'smooth',block:'start'})}};fh();addEventListener('hashchange',fh)}
try{var sv=new URLSearchParams(location.search).get('service');if(sv)$$('select[name=service]').forEach(function(s){[].slice.call(s.options).forEach(function(o){if(o.value==sv)s.value=sv})})}catch(e){}
/* chart */
var ch=$('.chart');if(ch){var cL=ch.dataset.labels.split(','),cV=ch.dataset.values.split(',').map(Number),cW=760,cH=320,pl=46,pr=16,pt=20,pb=36,tp=Math.ceil(Math.max.apply(null,cV)/200)*200||200;
var cX=function(i){return pl+i*(cW-pl-pr)/(cV.length-1)},cY=function(v){return pt+(cH-pt-pb)*(1-v/tp)};
var gr='';for(var k=0;k<=4;k++){var gv=tp*k/4,gy=cY(gv);gr+='<line x1="'+pl+'" x2="'+(cW-pr)+'" y1="'+gy+'" y2="'+gy+'" class="gl"/><text x="'+(pl-8)+'" y="'+(gy+4)+'" class="ax" text-anchor="end">'+Math.round(gv)+'</text>'}
var cd=cV.map(function(v,i){return(i?'L':'M')+cX(i).toFixed(1)+' '+cY(v).toFixed(1)}).join(' ');
var ca=cd+' L'+cX(cV.length-1)+' '+cY(0)+' L'+cX(0)+' '+cY(0)+'Z';
var cp=cV.map(function(v,i){return'<circle cx="'+cX(i)+'" cy="'+cY(v)+'" r="4.5" class="pt"><title>'+cL[i]+': '+v+'</title></circle>'}).join('');
var cl=cL.map(function(l,i){return'<text x="'+cX(i)+'" y="'+(cH-10)+'" class="ax" text-anchor="middle">'+l+'</text>'}).join('');
ch.querySelector('.plot').innerHTML='<svg viewBox="0 0 '+cW+' '+cH+'" role="img" aria-label="Leads delivered per month">'+gr+'<path d="'+ca+'" class="ar"/><path d="'+cd+'" class="ln2" pathLength="1"/>'+cp+cl+'</svg>';
if(ch.dataset.sample!='1'){var sp=ch.querySelector('.smp');if(sp)sp.remove()}
new IntersectionObserver(function(es,o){es.forEach(function(e){if(e.isIntersecting){ch.classList.add('go');o.disconnect()}})},{threshold:.3}).observe(ch)}
/* chatbot */
var P=$('#cbp');if(!P)return;
var M=$('#cbm'),F=$('#cbf'),I=$('input',F),step=0,lead={name:'',phone:'',email:'',service:'',message:'',consent:'chatbot'};
function add(t,c){var m=document.createElement('div');m.className='m '+c;m.textContent=t;M.appendChild(m);M.scrollTop=M.scrollHeight;return m}
function bot(t,cb){var m=add('...','b');setTimeout(function(){m.textContent=t;if(cb)cb();M.scrollTop=M.scrollHeight},600)}
function qr(list){var d=document.createElement('div');d.className='qr';list.forEach(function(s){var b=document.createElement('button');b.type='button';b.textContent=s;b.onclick=function(){d.remove();pick(s)};d.appendChild(b)});M.appendChild(d);M.scrollTop=M.scrollHeight}
function start(){M.innerHTML='';step=0;bot('Hi, I’m the Loadhub assistant. What can we help you with?',function(){qr(['Auto','Health','Finance','Insurance','Partner with us'])})}
function pick(s){add(s,'u');lead.service=s;step=1;bot('Great choice. What is your name?')}
function fin(){step=4;bot('Thanks '+lead.name+'. Sending your request now. We reply within 24 hours.',function(){
send(lead).catch(function(){});var a=document.createElement('a');a.className='btn s';a.target='_blank';a.rel='noopener';a.style.alignSelf='flex-start';a.href=wa(summary(lead));a.innerHTML='<svg class="i" aria-hidden="true"><use href="#brands-whatsapp"/></svg> Continue on WhatsApp';M.appendChild(a);M.scrollTop=M.scrollHeight})}
F.addEventListener('submit',function(e){e.preventDefault();var v=I.value.trim();if(!v||step==0||step>3)return;I.value='';add(v,'u');
if(step==1){lead.name=v;step=2;bot('Nice to meet you, '+v+'. What is your phone number?')}
else if(step==2){lead.phone=v;step=3;bot('And your email address?')}
else if(step==3){if(v.indexOf('@')<1){bot('That email looks incomplete. Please try again.');return}lead.email=v;fin()}});
$('#cbt').onclick=function(){var o=P.classList.toggle('open');if(o&&!M.children.length)start()};
$('#cbx').onclick=function(){P.classList.remove('open')};
})();
