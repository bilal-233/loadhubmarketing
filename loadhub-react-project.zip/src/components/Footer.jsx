import { Link, useLocation } from 'react-router-dom'
import Logo from './Logo'
import Icon from './Icon'

const social = [
  ['Facebook', '#', 'brands-facebook-f'], ['Instagram', '#', 'brands-instagram'], ['LinkedIn', '#', 'brands-linkedin-in'],
  ['X', '#', 'brands-x-twitter'], ['YouTube', '#', 'brands-youtube'], ['TikTok', '#', 'brands-tiktok'],
  ['Telegram', 'https://t.me/Loadhub_america', 'brands-telegram', true], ['WhatsApp', 'https://wa.me/16468956658', 'brands-whatsapp', true],
]
const popular = [
  ['auto-insurance', 'Auto Insurance'], ['home-insurance', 'Home Insurance'], ['health-insurance', 'Health Insurance'],
  ['life-insurance', 'Life Insurance'], ['general-liability', 'General Liability'], ['workers-compensation', 'Workers’ Compensation'],
  ['cyber-insurance', 'Cyber Insurance'], ['commercial-auto', 'Commercial Auto'],
]

export default function Footer() {
  const { pathname } = useLocation()
  const home = pathname === '/' || pathname === '/index.html'
  return (
    <footer>
      <div className="wrap">
        <div className="grid">
          <div>
            {home
              ? <a className="logo" href="#top" style={{ color: '#fff' }}><Logo gid="gf" /><span>Loadhub Marketing</span></a>
              : <Link className="logo" to="/" style={{ color: '#fff' }}><Logo gid="gf" /><span>Loadhub Marketing</span></Link>}
            <p style={{ marginTop: '14px', maxWidth: '34ch' }}>Performance marketing and lead generation partner for auto, health, finance and insurance brands in the United States.</p>
            <div className="soc">
              {social.map(([label, href, icon, ext]) => (
                <a key={label} aria-label={label} href={href} {...(ext ? { rel: 'noopener', target: '_blank' } : {})}><Icon id={icon} /></a>
              ))}
            </div>
          </div>
          <div>
            <h4>Company</h4>
            <ul>
              <li>{home ? <a href="#top">Home</a> : <Link to="/">Home</Link>}</li>
              <li>{home ? <a href="#services">Services</a> : <Link to="/services.html">Services</Link>}</li>
              <li><Link to="/clients.html">Clients</Link></li>
              <li><Link to="/about.html">About us</Link></li>
              <li><Link to="/contact.html">Contact</Link></li>
              <li><Link to="/partner.html">Partner with us</Link></li>
            </ul>
          </div>
          <div>
            <h4>Legal</h4>
            <ul>
              <li><Link to="/privacy.html">Privacy policy</Link></li>
              <li><Link to="/terms.html">Terms of service</Link></li>
              <li><Link to="/disclaimer.html">Disclaimer</Link></li>
            </ul>
          </div>
          <div>
            <h4>Get in touch</h4>
            <ul>
              <li style={{ color: '#fff', fontWeight: 600 }}>M. Tayyab, CEO</li>
              <li><a href="mailto:Marketing@loadhubamerica.com"><Icon id="solid-envelope" /> Marketing@loadhubamerica.com</a></li>
              <li><a href="https://wa.me/16468956658"><Icon id="brands-whatsapp" /> +1 (646) 895-6658</a></li>
              <li><Icon id="solid-location-dot" /> 22518 Woodcreek Dr, Brownstown Twp, MI 48134, United States</li>
              <li><a href="https://t.me/Loadhub_america"><Icon id="brands-telegram" /> @Loadhub_america</a></li>
            </ul>
          </div>
        </div>
        <p className="fs">Popular: {popular.map(([s, l]) => <Link key={s} to={`/${s}.html`}>{l}</Link>)}</p>
        <div className="fl">
          <Link to="/privacy.html">Privacy Policy</Link>
          <Link to="/terms.html">Terms of Service</Link>
          <Link to="/disclaimer.html">Disclaimer</Link>
        </div>
        <p className="copy">© <span id="yr" suppressHydrationWarning>{new Date().getFullYear()}</span> Loadhub Marketing. All rights reserved. Loadhub Marketing is a lead generation company, not an insurance carrier, agency or lender.</p>
      </div>
    </footer>
  )
}
