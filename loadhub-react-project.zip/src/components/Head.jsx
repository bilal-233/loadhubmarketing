import { useEffect } from 'react'
import { applyHead } from '../lib/head'

export default function Head({ head }) {
  useEffect(() => { applyHead(head) }, [head])
  return null
}
