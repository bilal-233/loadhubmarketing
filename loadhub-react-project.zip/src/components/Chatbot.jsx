import { useEffect, useRef, useState } from 'react'
import Icon from './Icon'
import { send, summary, wa } from '../lib/lead'

const SERVICES = ['Auto', 'Health', 'Finance', 'Insurance', 'Partner with us']

export default function Chatbot() {
  const [open, setOpen] = useState(false)
  const [items, setItems] = useState([])
  const [text, setText] = useState('')
  const step = useRef(0)
  const lead = useRef({ name: '', phone: '', email: '', service: '', message: '', consent: 'chatbot' })
  const idc = useRef(0)
  const box = useRef(null)
  const timers = useRef([])

  useEffect(() => { if (box.current) box.current.scrollTop = box.current.scrollHeight }, [items])
  useEffect(() => () => timers.current.forEach(clearTimeout), [])

  const nid = () => ++idc.current
  const add = (t, c) => setItems((l) => [...l, { id: nid(), kind: 'm', cls: c, text: t }])
  const bot = (t, cb) => {
    const id = nid()
    setItems((l) => [...l, { id, kind: 'm', cls: 'b', text: '...' }])
    timers.current.push(setTimeout(() => {
      setItems((l) => l.map((x) => (x.id === id ? { ...x, text: t } : x)))
      if (cb) cb()
    }, 600))
  }
  const start = () => {
    setItems([]); step.current = 0
    bot('Hi, I’m the Loadhub assistant. What can we help you with?', () =>
      setItems((l) => [...l, { id: nid(), kind: 'qr', options: SERVICES }]))
  }
  const pick = (qrId, s) => {
    setItems((l) => l.filter((x) => x.id !== qrId))
    add(s, 'u'); lead.current.service = s; step.current = 1
    bot('Great choice. What is your name?')
  }
  const fin = () => {
    step.current = 4
    bot('Thanks ' + lead.current.name + '. Sending your request now. We reply within 24 hours.', () => {
      send(lead.current).catch(() => {})
      setItems((l) => [...l, { id: nid(), kind: 'wa', href: wa(summary(lead.current)) }])
    })
  }
  const onSubmit = (e) => {
    e.preventDefault()
    const v = text.trim()
    if (!v || step.current === 0 || step.current > 3) return
    setText(''); add(v, 'u')
    if (step.current === 1) { lead.current.name = v; step.current = 2; bot('Nice to meet you, ' + v + '. What is your phone number?') }
    else if (step.current === 2) { lead.current.phone = v; step.current = 3; bot('And your email address?') }
    else if (step.current === 3) {
      if (v.indexOf('@') < 1) { bot('That email looks incomplete. Please try again.'); return }
      lead.current.email = v; fin()
    }
  }
  const toggle = () => {
    const o = !open
    setOpen(o)
    if (o && items.length === 0) start()
  }

  return (
    <div className="cb">
      <div aria-label="Chat" className={'cbp' + (open ? ' open' : '')} id="cbp" role="dialog">
        <div className="cbh">
          <span>Loadhub Assistant<small>Replies instantly</small></span>
          <button aria-label="Close" id="cbx" onClick={() => setOpen(false)}><Icon id="solid-xmark" /></button>
        </div>
        <div aria-live="polite" className="cbm" id="cbm" ref={box}>
          {items.map((it) => {
            if (it.kind === 'm') return <div key={it.id} className={'m ' + it.cls}>{it.text}</div>
            if (it.kind === 'qr') return (
              <div key={it.id} className="qr">
                {it.options.map((s) => <button key={s} type="button" onClick={() => pick(it.id, s)}>{s}</button>)}
              </div>
            )
            return (
              <a key={it.id} className="btn s" target="_blank" rel="noopener" style={{ alignSelf: 'flex-start' }} href={it.href}>
                <Icon id="brands-whatsapp" /> Continue on WhatsApp
              </a>
            )
          })}
        </div>
        <form className="cbf" id="cbf" onSubmit={onSubmit}>
          <input aria-label="Message" placeholder="Type your answer" value={text} onChange={(e) => setText(e.target.value)} />
          <button aria-label="Send"><Icon id="solid-paper-plane" /></button>
        </form>
      </div>
      <button aria-label="Open chat" className="cbt" id="cbt" onClick={toggle}><Icon id="solid-comments" /></button>
    </div>
  )
}
