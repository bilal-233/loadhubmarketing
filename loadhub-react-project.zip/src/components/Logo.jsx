export default function Logo({ gid }) {
  return (
    <svg aria-hidden="true" width="40" height="40" viewBox="0 0 48 48">
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#1e5bff" />
          <stop offset="1" stopColor="#12b894" />
        </linearGradient>
      </defs>
      <path d="M24 3 42 10v14c0 11-8 18-18 21C14 42 6 35 6 24V10z" fill={`url(#${gid})`} />
      <g stroke="#fff" strokeLinecap="round" strokeWidth="2.2"><path d="M24 24 15 16M24 24l9-8M24 24v12" /></g>
      <g fill="#fff">
        <circle cx="24" cy="24" r="4.5" />
        <circle cx="14" cy="15" r="3" />
        <circle cx="34" cy="15" r="3" />
        <circle cx="24" cy="37" r="3" />
      </g>
    </svg>
  )
}
