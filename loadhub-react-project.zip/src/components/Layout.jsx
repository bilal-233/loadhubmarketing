import { useEffect, useRef } from 'react'
import { useLocation } from 'react-router-dom'
import Sprite from './Sprite'
import Header from './Header'
import Footer from './Footer'
import Chatbot from './Chatbot'
import Icon from './Icon'
import { initPage, applyHash } from '../lib/behaviors'

export default function Layout({ children }) {
  const { pathname, hash } = useLocation()
  const first = useRef(true)

  // per-page behaviours (reveal, counters, forms, tabs, chart)
  useEffect(() => {
    const cleanup = initPage()
    if (!applyHash() && !first.current) window.scrollTo(0, 0)
    first.current = false
    return cleanup
  }, [pathname])

  // same-page hash navigation (e.g. /services.html#business)
  useEffect(() => { applyHash() }, [hash])

  return (
    <>
      <Sprite />
      <Header />
      {children}
      <Footer />
      <a className="wa" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing" target="_blank" rel="noopener" aria-label="Chat on WhatsApp"><Icon id="brands-whatsapp" /></a>
      <Chatbot />
    </>
  )
}
