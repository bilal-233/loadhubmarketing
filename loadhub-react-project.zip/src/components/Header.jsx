import { useEffect, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import Logo from './Logo'
import Icon from './Icon'

export default function Header() {
  const { pathname } = useLocation()
  const home = pathname === '/' || pathname === '/index.html'
  const [theme, setTheme] = useState('light')
  const [open, setOpen] = useState(false)

  // pick up the theme the inline <head> script already applied
  useEffect(() => {
    setTheme(document.documentElement.getAttribute('data-theme') || 'light')
  }, [])
  useEffect(() => { setOpen(false) }, [pathname])

  const toggleTheme = () => {
    const t = theme === 'dark' ? 'light' : 'dark'
    setTheme(t)
    document.documentElement.setAttribute('data-theme', t)
    try { localStorage.setItem('lh-theme', t) } catch (e) { /* ignore */ }
  }
  const close = () => setOpen(false)
  const on = (p) => (pathname === p ? 'l on' : 'l')

  return (
    <header>
      <div className="wrap nav">
        {home ? (
          <a className="logo" href="#top" aria-label="Loadhub Marketing home"><Logo gid="gh" /><span>Loadhub Marketing<small>Lead generation, done right</small></span></a>
        ) : (
          <Link className="logo" to="/" aria-label="Loadhub Marketing home"><Logo gid="gh" /><span>Loadhub Marketing<small>Lead generation, done right</small></span></Link>
        )}
        <nav aria-label="Main" className={open ? 'open' : undefined}>
          <ul>
            <li>{home ? <a className="l on" href="#top" onClick={close}>Home</a> : <Link className="l" to="/" onClick={close}>Home</Link>}</li>
            <li>{home ? <a className="l" href="#personal" onClick={close}>Personal</a> : <Link className="l" to="/services.html#personal" onClick={close}>Personal</Link>}</li>
            <li>{home ? <a className="l" href="#business" onClick={close}>Business</a> : <Link className="l" to="/services.html#business" onClick={close}>Business</Link>}</li>
            <li><Link className={on('/clients.html')} to="/clients.html" onClick={close}>Clients</Link></li>
            <li><Link className={on('/about.html')} to="/about.html" onClick={close}>About</Link></li>
            <li><Link className={on('/contact.html')} to="/contact.html" onClick={close}>Contact</Link></li>
          </ul>
        </nav>
        <div className="tools">
          <button className="ic" id="theme" aria-label="Toggle dark mode" onClick={toggleTheme}>
            <Icon id={theme === 'dark' ? 'solid-sun' : 'solid-moon'} />
          </button>
          <Link className="btn p hdcta" to="/partner.html">Partner With Us</Link>
          <button className="ic burger" id="burger" aria-label="Menu" aria-expanded={open} onClick={() => setOpen((o) => !o)}>
            <Icon id="solid-bars" />
          </button>
        </div>
      </div>
    </header>
  )
}
