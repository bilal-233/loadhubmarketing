import { Link } from 'react-router-dom'

export const head = {
  "title": "Long-Term Care Quotes | Loadhub Marketing",
  "tags": [
    {
      "name": "description",
      "content": "Coverage for extended care at home or in a facility. Request a free Long-Term Care quote through Loadhub Marketing."
    },
    {
      "name": "robots",
      "content": "index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1"
    },
    {
      "property": "og:type",
      "content": "website"
    },
    {
      "property": "og:title",
      "content": "Long-Term Care Quotes | Loadhub Marketing"
    },
    {
      "property": "og:description",
      "content": "Coverage for extended care at home or in a facility. Request a free Long-Term Care quote through Loadhub Marketing."
    },
    {
      "property": "og:url",
      "content": "https://loadhubmarketing.com/long-term-care.html"
    },
    {
      "property": "og:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    },
    {
      "property": "og:image:width",
      "content": "1200"
    },
    {
      "property": "og:image:height",
      "content": "630"
    },
    {
      "property": "og:image:alt",
      "content": "Loadhub Marketing, insurance lead generation"
    },
    {
      "property": "og:site_name",
      "content": "Loadhub Marketing"
    },
    {
      "property": "og:locale",
      "content": "en_US"
    },
    {
      "name": "twitter:card",
      "content": "summary_large_image"
    },
    {
      "name": "twitter:title",
      "content": "Long-Term Care Quotes | Loadhub Marketing"
    },
    {
      "name": "twitter:description",
      "content": "Coverage for extended care at home or in a facility. Request a free Long-Term Care quote through Loadhub Marketing."
    },
    {
      "name": "twitter:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    }
  ],
  "canonical": "https://loadhubmarketing.com/long-term-care.html"
}

export default function LongTermCare() {
  return (
    <main>
        <section className="phead">
          <div className="wrap">
            <p className="bc">
              <Link to="/">
                Home
              </Link>
              {" / "}
              <Link to="/services.html#special">
                Special
              </Link>
              {" / Long-Term Care"}
            </p>
            <div className="dh">
              <div className="ico big">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-bed-pulse" />
                </svg>
              </div>
              <div>
                <h1 style={{fontSize:"clamp(2rem,4.5vw,3.2rem)"}}>
                  Long-Term Care
                </h1>
                <p className="lead">
                  Coverage for extended care at home or in a facility.
                </p>
              </div>
            </div>
            <div style={{display:"flex",gap:".8rem",flexWrap:"wrap",marginTop:"22px"}}>
              <Link to="/contact.html?service=Long-Term%20Care#quote" className="btn p">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-paper-plane" />
                </svg>
                {" Get a quote"}
              </Link>
              <a className="btn o" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Long-Term%20Care" target="_blank" rel="noopener">
                <svg className="i" aria-hidden="true">
                  <use href="#brands-whatsapp" />
                </svg>
                {" WhatsApp us"}
              </a>
            </div>
          </div>
        </section>
        <section style={{paddingTop:"20px"}}>
          <div className="wrap split">
            <div>
              <h2>
                What it covers
              </h2>
              <ul className="cv">
                <li>
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-check" />
                  </svg>
                  <span>
                    Home health care
                  </span>
                </li>
                <li>
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-check" />
                  </svg>
                  <span>
                    Assisted living
                  </span>
                </li>
                <li>
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-check" />
                  </svg>
                  <span>
                    Nursing facility care
                  </span>
                </li>
                <li>
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-check" />
                  </svg>
                  <span>
                    Adult day services
                  </span>
                </li>
              </ul>
              <h2 style={{marginTop:"30px"}}>
                Who it is for
              </h2>
              <p className="lead">
                Adults planning ahead for care later in life.
              </p>
            </div>
            <div className="card">
              <h3>
                Get a free quote
              </h3>
              <p>
                Choose Long-Term Care on our form and a partner will get back to you. It takes about a minute.
              </p>
              <br />
              <Link to="/contact.html?service=Long-Term%20Care#quote" className="btn s">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-paper-plane" />
                </svg>
                {" Get a quote"}
              </Link>
            </div>
          </div>
        </section>
        <section className="alt">
          <div className="wrap doc">
            <h2>
              Frequently asked questions
            </h2>
            <br />
            <details>
              <summary>
                What does Long-Term Care cover?
              </summary>
              <p>
                Typical coverage includes: home health care; assisted living; nursing facility care; adult day services. Exact terms depend on the provider and the plan you choose.
              </p>
            </details>
            <details>
              <summary>
                Who needs Long-Term Care?
              </summary>
              <p>
                Adults planning ahead for care later in life.
              </p>
            </details>
            <details>
              <summary>
                How do I get a quote?
              </summary>
              <p>
                Select Get a quote, choose Long-Term Care and send your details. One of our partners will contact you with options.
              </p>
            </details>
            <details>
              <summary>
                Does it cost anything to request a quote?
              </summary>
              <p>
                No. Requesting a quote through Loadhub Marketing is free and does not oblige you to buy.
              </p>
            </details>
            <details>
              <summary>
                Is Loadhub Marketing the provider?
              </summary>
              <p>
                No. We are a lead generation company. Independent partners make the offers and provide the service.
              </p>
            </details>
          </div>
        </section>
        <section>
          <div className="wrap">
            <div className="head">
              <h2>
                More in Special
              </h2>
            </div>
            <div className="grid g3">
              <article className="card sc rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-wheelchair" />
                  </svg>
                </div>
                <h3>
                  <Link to="/disability-insurance.html">
                    Disability Insurance
                  </Link>
                </h3>
                <p>
                  Income protection if you cannot work.
                </p>
                <div className="act">
                  <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Disability%20Insurance" target="_blank" rel="noopener">
                    <svg className="i" aria-hidden="true">
                      <use href="#brands-whatsapp" />
                    </svg>
                    {" WhatsApp"}
                  </a>
                  <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Disability%20Insurance&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Disability%20Insurance.%0A%0AName%3A%0APhone%3A%0A"}>
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-envelope" />
                    </svg>
                    {" Email"}
                  </a>
                </div>
              </article>
              <article className="card sc rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-piggy-bank" />
                  </svg>
                </div>
                <h3>
                  <Link to="/annuities-retirement.html">
                    Annuities / Retirement
                  </Link>
                </h3>
                <p>
                  Steady income for retirement.
                </p>
                <div className="act">
                  <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Annuities%20/%20Retirement" target="_blank" rel="noopener">
                    <svg className="i" aria-hidden="true">
                      <use href="#brands-whatsapp" />
                    </svg>
                    {" WhatsApp"}
                  </a>
                  <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Annuities%20/%20Retirement&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Annuities%20/%20Retirement.%0A%0AName%3A%0APhone%3A%0A"}>
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-envelope" />
                    </svg>
                    {" Email"}
                  </a>
                </div>
              </article>
              <article className="card sc rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-truck-moving" />
                  </svg>
                </div>
                <h3>
                  <Link to="/trucking-insurance.html">
                    Trucking Insurance
                  </Link>
                </h3>
                <p>
                  Coverage for owner-operators and fleets.
                </p>
                <div className="act">
                  <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Trucking%20Insurance" target="_blank" rel="noopener">
                    <svg className="i" aria-hidden="true">
                      <use href="#brands-whatsapp" />
                    </svg>
                    {" WhatsApp"}
                  </a>
                  <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Trucking%20Insurance&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Trucking%20Insurance.%0A%0AName%3A%0APhone%3A%0A"}>
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-envelope" />
                    </svg>
                    {" Email"}
                  </a>
                </div>
              </article>
            </div>
          </div>
        </section>
        <script type="application/ld+json" dangerouslySetInnerHTML={{__html:"{\"@context\":\"https://schema.org\",\"@type\":\"FAQPage\",\"mainEntity\":[{\"@type\":\"Question\",\"name\":\"What does Long-Term Care cover?\",\"acceptedAnswer\":{\"@type\":\"Answer\",\"text\":\"Typical coverage includes: home health care; assisted living; nursing facility care; adult day services. Exact terms depend on the provider and the plan you choose.\"}},{\"@type\":\"Question\",\"name\":\"Who needs Long-Term Care?\",\"acceptedAnswer\":{\"@type\":\"Answer\",\"text\":\"Adults planning ahead for care later in life.\"}},{\"@type\":\"Question\",\"name\":\"How do I get a quote?\",\"acceptedAnswer\":{\"@type\":\"Answer\",\"text\":\"Select Get a quote, choose Long-Term Care and send your details. One of our partners will contact you with options.\"}},{\"@type\":\"Question\",\"name\":\"Does it cost anything to request a quote?\",\"acceptedAnswer\":{\"@type\":\"Answer\",\"text\":\"No. Requesting a quote through Loadhub Marketing is free and does not oblige you to buy.\"}},{\"@type\":\"Question\",\"name\":\"Is Loadhub Marketing the provider?\",\"acceptedAnswer\":{\"@type\":\"Answer\",\"text\":\"No. We are a lead generation company. Independent partners make the offers and provide the service.\"}}]}"}} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{__html:"{\"@context\":\"https://schema.org\",\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"Home\",\"item\":\"https://loadhubmarketing.com/\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"Special\",\"item\":\"https://loadhubmarketing.com/services.html#special\"},{\"@type\":\"ListItem\",\"position\":3,\"name\":\"Long-Term Care\",\"item\":\"https://loadhubmarketing.com/long-term-care.html\"}]}"}} />
      </main>
  )
}
