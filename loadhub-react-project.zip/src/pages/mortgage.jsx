import { Link } from 'react-router-dom'

export const head = {
  "title": "Mortgage Quotes | Loadhub Marketing",
  "tags": [
    {
      "name": "description",
      "content": "Purchase and refinance loan options. Request a free Mortgage quote through Loadhub Marketing."
    },
    {
      "name": "robots",
      "content": "index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1"
    },
    {
      "property": "og:type",
      "content": "website"
    },
    {
      "property": "og:title",
      "content": "Mortgage Quotes | Loadhub Marketing"
    },
    {
      "property": "og:description",
      "content": "Purchase and refinance loan options. Request a free Mortgage quote through Loadhub Marketing."
    },
    {
      "property": "og:url",
      "content": "https://loadhubmarketing.com/mortgage.html"
    },
    {
      "property": "og:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    },
    {
      "property": "og:image:width",
      "content": "1200"
    },
    {
      "property": "og:image:height",
      "content": "630"
    },
    {
      "property": "og:image:alt",
      "content": "Loadhub Marketing, insurance lead generation"
    },
    {
      "property": "og:site_name",
      "content": "Loadhub Marketing"
    },
    {
      "property": "og:locale",
      "content": "en_US"
    },
    {
      "name": "twitter:card",
      "content": "summary_large_image"
    },
    {
      "name": "twitter:title",
      "content": "Mortgage Quotes | Loadhub Marketing"
    },
    {
      "name": "twitter:description",
      "content": "Purchase and refinance loan options. Request a free Mortgage quote through Loadhub Marketing."
    },
    {
      "name": "twitter:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    }
  ],
  "canonical": "https://loadhubmarketing.com/mortgage.html"
}

export default function Mortgage() {
  return (
    <main>
        <section className="phead">
          <div className="wrap">
            <p className="bc">
              <Link to="/">
                Home
              </Link>
              {" / "}
              <Link to="/services.html#finance">
                Finance
              </Link>
              {" / Mortgage"}
            </p>
            <div className="dh">
              <div className="ico big">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-key" />
                </svg>
              </div>
              <div>
                <h1 style={{fontSize:"clamp(2rem,4.5vw,3.2rem)"}}>
                  Mortgage
                </h1>
                <p className="lead">
                  Purchase and refinance loan options.
                </p>
              </div>
            </div>
            <div style={{display:"flex",gap:".8rem",flexWrap:"wrap",marginTop:"22px"}}>
              <Link to="/contact.html?service=Mortgage#quote" className="btn p">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-paper-plane" />
                </svg>
                {" Get a quote"}
              </Link>
              <a className="btn o" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Mortgage" target="_blank" rel="noopener">
                <svg className="i" aria-hidden="true">
                  <use href="#brands-whatsapp" />
                </svg>
                {" WhatsApp us"}
              </a>
            </div>
          </div>
        </section>
        <section style={{paddingTop:"20px"}}>
          <div className="wrap split">
            <div>
              <h2>
                What it covers
              </h2>
              <ul className="cv">
                <li>
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-check" />
                  </svg>
                  <span>
                    Home purchase loans
                  </span>
                </li>
                <li>
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-check" />
                  </svg>
                  <span>
                    Refinancing
                  </span>
                </li>
                <li>
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-check" />
                  </svg>
                  <span>
                    FHA, VA and conventional options
                  </span>
                </li>
                <li>
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-check" />
                  </svg>
                  <span>
                    Rate comparisons
                  </span>
                </li>
              </ul>
              <h2 style={{marginTop:"30px"}}>
                Who it is for
              </h2>
              <p className="lead">
                Buyers and owners comparing mortgage offers.
              </p>
            </div>
            <div className="card">
              <h3>
                Get a free quote
              </h3>
              <p>
                Choose Mortgage on our form and a partner will get back to you. It takes about a minute.
              </p>
              <br />
              <Link to="/contact.html?service=Mortgage#quote" className="btn s">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-paper-plane" />
                </svg>
                {" Get a quote"}
              </Link>
            </div>
          </div>
        </section>
        <section className="alt">
          <div className="wrap doc">
            <h2>
              Frequently asked questions
            </h2>
            <br />
            <details>
              <summary>
                What does Mortgage cover?
              </summary>
              <p>
                Typical options include: home purchase loans; refinancing; fHA, VA and conventional options; rate comparisons. Exact terms depend on the provider and the plan you choose.
              </p>
            </details>
            <details>
              <summary>
                Who needs Mortgage?
              </summary>
              <p>
                Buyers and owners comparing mortgage offers.
              </p>
            </details>
            <details>
              <summary>
                How do I get a quote?
              </summary>
              <p>
                Select Get a quote, choose Mortgage and send your details. One of our partners will contact you with options.
              </p>
            </details>
            <details>
              <summary>
                Does it cost anything to request a quote?
              </summary>
              <p>
                No. Requesting a quote through Loadhub Marketing is free and does not oblige you to buy.
              </p>
            </details>
            <details>
              <summary>
                Is Loadhub Marketing the provider?
              </summary>
              <p>
                No. We are a lead generation company. Independent partners make the offers and provide the service.
              </p>
            </details>
          </div>
        </section>
        <section>
          <div className="wrap">
            <div className="head">
              <h2>
                More in Finance
              </h2>
            </div>
            <div className="grid g3">
              <article className="card sc rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-money-bill-wave" />
                  </svg>
                </div>
                <h3>
                  <Link to="/personal-loans.html">
                    Personal Loans
                  </Link>
                </h3>
                <p>
                  Compare personal loan offers.
                </p>
                <div className="act">
                  <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Personal%20Loans" target="_blank" rel="noopener">
                    <svg className="i" aria-hidden="true">
                      <use href="#brands-whatsapp" />
                    </svg>
                    {" WhatsApp"}
                  </a>
                  <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Personal%20Loans&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Personal%20Loans.%0A%0AName%3A%0APhone%3A%0A"}>
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-envelope" />
                    </svg>
                    {" Email"}
                  </a>
                </div>
              </article>
              <article className="card sc rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-file-invoice-dollar" />
                  </svg>
                </div>
                <h3>
                  <Link to="/debt-relief.html">
                    Debt Relief
                  </Link>
                </h3>
                <p>
                  Options to manage and reduce unsecured debt.
                </p>
                <div className="act">
                  <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Debt%20Relief" target="_blank" rel="noopener">
                    <svg className="i" aria-hidden="true">
                      <use href="#brands-whatsapp" />
                    </svg>
                    {" WhatsApp"}
                  </a>
                  <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Debt%20Relief&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Debt%20Relief.%0A%0AName%3A%0APhone%3A%0A"}>
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-envelope" />
                    </svg>
                    {" Email"}
                  </a>
                </div>
              </article>
              <article className="card sc rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-credit-card" />
                  </svg>
                </div>
                <h3>
                  <Link to="/credit-repair.html">
                    Credit Repair
                  </Link>
                </h3>
                <p>
                  Help correcting errors and rebuilding credit.
                </p>
                <div className="act">
                  <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Credit%20Repair" target="_blank" rel="noopener">
                    <svg className="i" aria-hidden="true">
                      <use href="#brands-whatsapp" />
                    </svg>
                    {" WhatsApp"}
                  </a>
                  <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Credit%20Repair&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Credit%20Repair.%0A%0AName%3A%0APhone%3A%0A"}>
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-envelope" />
                    </svg>
                    {" Email"}
                  </a>
                </div>
              </article>
            </div>
          </div>
        </section>
        <script type="application/ld+json" dangerouslySetInnerHTML={{__html:"{\"@context\":\"https://schema.org\",\"@type\":\"FAQPage\",\"mainEntity\":[{\"@type\":\"Question\",\"name\":\"What does Mortgage cover?\",\"acceptedAnswer\":{\"@type\":\"Answer\",\"text\":\"Typical options include: home purchase loans; refinancing; fHA, VA and conventional options; rate comparisons. Exact terms depend on the provider and the plan you choose.\"}},{\"@type\":\"Question\",\"name\":\"Who needs Mortgage?\",\"acceptedAnswer\":{\"@type\":\"Answer\",\"text\":\"Buyers and owners comparing mortgage offers.\"}},{\"@type\":\"Question\",\"name\":\"How do I get a quote?\",\"acceptedAnswer\":{\"@type\":\"Answer\",\"text\":\"Select Get a quote, choose Mortgage and send your details. One of our partners will contact you with options.\"}},{\"@type\":\"Question\",\"name\":\"Does it cost anything to request a quote?\",\"acceptedAnswer\":{\"@type\":\"Answer\",\"text\":\"No. Requesting a quote through Loadhub Marketing is free and does not oblige you to buy.\"}},{\"@type\":\"Question\",\"name\":\"Is Loadhub Marketing the provider?\",\"acceptedAnswer\":{\"@type\":\"Answer\",\"text\":\"No. We are a lead generation company. Independent partners make the offers and provide the service.\"}}]}"}} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{__html:"{\"@context\":\"https://schema.org\",\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"Home\",\"item\":\"https://loadhubmarketing.com/\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"Finance\",\"item\":\"https://loadhubmarketing.com/services.html#finance\"},{\"@type\":\"ListItem\",\"position\":3,\"name\":\"Mortgage\",\"item\":\"https://loadhubmarketing.com/mortgage.html\"}]}"}} />
      </main>
  )
}
