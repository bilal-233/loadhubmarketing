import { Link } from 'react-router-dom'

export const head = {
  "title": "General Liability Quotes | Loadhub Marketing",
  "tags": [
    {
      "name": "description",
      "content": "Protection from customer injury and property damage claims. Request a free General Liability quote through Loadhub Marketing."
    },
    {
      "name": "robots",
      "content": "index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1"
    },
    {
      "property": "og:type",
      "content": "website"
    },
    {
      "property": "og:title",
      "content": "General Liability Quotes | Loadhub Marketing"
    },
    {
      "property": "og:description",
      "content": "Protection from customer injury and property damage claims. Request a free General Liability quote through Loadhub Marketing."
    },
    {
      "property": "og:url",
      "content": "https://loadhubmarketing.com/general-liability.html"
    },
    {
      "property": "og:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    },
    {
      "property": "og:image:width",
      "content": "1200"
    },
    {
      "property": "og:image:height",
      "content": "630"
    },
    {
      "property": "og:image:alt",
      "content": "Loadhub Marketing, insurance lead generation"
    },
    {
      "property": "og:site_name",
      "content": "Loadhub Marketing"
    },
    {
      "property": "og:locale",
      "content": "en_US"
    },
    {
      "name": "twitter:card",
      "content": "summary_large_image"
    },
    {
      "name": "twitter:title",
      "content": "General Liability Quotes | Loadhub Marketing"
    },
    {
      "name": "twitter:description",
      "content": "Protection from customer injury and property damage claims. Request a free General Liability quote through Loadhub Marketing."
    },
    {
      "name": "twitter:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    }
  ],
  "canonical": "https://loadhubmarketing.com/general-liability.html"
}

export default function GeneralLiability() {
  return (
    <main>
        <section className="phead">
          <div className="wrap">
            <p className="bc">
              <Link to="/">
                Home
              </Link>
              {" / "}
              <Link to="/services.html#business">
                Business
              </Link>
              {" / General Liability"}
            </p>
            <div className="dh">
              <div className="ico big">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-scale-balanced" />
                </svg>
              </div>
              <div>
                <h1 style={{fontSize:"clamp(2rem,4.5vw,3.2rem)"}}>
                  General Liability
                </h1>
                <p className="lead">
                  Protection from customer injury and property damage claims.
                </p>
              </div>
            </div>
            <div style={{display:"flex",gap:".8rem",flexWrap:"wrap",marginTop:"22px"}}>
              <Link to="/contact.html?service=General%20Liability#quote" className="btn p">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-paper-plane" />
                </svg>
                {" Get a quote"}
              </Link>
              <a className="btn o" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20General%20Liability" target="_blank" rel="noopener">
                <svg className="i" aria-hidden="true">
                  <use href="#brands-whatsapp" />
                </svg>
                {" WhatsApp us"}
              </a>
            </div>
          </div>
        </section>
        <section style={{paddingTop:"20px"}}>
          <div className="wrap split">
            <div>
              <h2>
                What it covers
              </h2>
              <ul className="cv">
                <li>
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-check" />
                  </svg>
                  <span>
                    Customer injury claims
                  </span>
                </li>
                <li>
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-check" />
                  </svg>
                  <span>
                    Damage to other people’s property
                  </span>
                </li>
                <li>
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-check" />
                  </svg>
                  <span>
                    Advertising injury
                  </span>
                </li>
                <li>
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-check" />
                  </svg>
                  <span>
                    Legal defense costs
                  </span>
                </li>
              </ul>
              <h2 style={{marginTop:"30px"}}>
                Who it is for
              </h2>
              <p className="lead">
                Almost any business that deals with customers or works on client sites.
              </p>
            </div>
            <div className="card">
              <h3>
                Get a free quote
              </h3>
              <p>
                Choose General Liability on our form and a partner will get back to you. It takes about a minute.
              </p>
              <br />
              <Link to="/contact.html?service=General%20Liability#quote" className="btn s">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-paper-plane" />
                </svg>
                {" Get a quote"}
              </Link>
            </div>
          </div>
        </section>
        <section className="alt">
          <div className="wrap doc">
            <h2>
              Frequently asked questions
            </h2>
            <br />
            <details>
              <summary>
                What does General Liability cover?
              </summary>
              <p>
                Typical coverage includes: customer injury claims; damage to other people’s property; advertising injury; legal defense costs. Exact terms depend on the provider and the plan you choose.
              </p>
            </details>
            <details>
              <summary>
                Who needs General Liability?
              </summary>
              <p>
                Almost any business that deals with customers or works on client sites.
              </p>
            </details>
            <details>
              <summary>
                How do I get a quote?
              </summary>
              <p>
                Select Get a quote, choose General Liability and send your details. One of our partners will contact you with options.
              </p>
            </details>
            <details>
              <summary>
                Does it cost anything to request a quote?
              </summary>
              <p>
                No. Requesting a quote through Loadhub Marketing is free and does not oblige you to buy.
              </p>
            </details>
            <details>
              <summary>
                Is Loadhub Marketing the provider?
              </summary>
              <p>
                No. We are a lead generation company. Independent partners make the offers and provide the service.
              </p>
            </details>
          </div>
        </section>
        <section>
          <div className="wrap">
            <div className="head">
              <h2>
                More in Business
              </h2>
            </div>
            <div className="grid g3">
              <article className="card sc rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-truck" />
                  </svg>
                </div>
                <h3>
                  <Link to="/commercial-auto.html">
                    Commercial Auto
                  </Link>
                </h3>
                <p>
                  Coverage for vehicles used in your business.
                </p>
                <div className="act">
                  <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Commercial%20Auto" target="_blank" rel="noopener">
                    <svg className="i" aria-hidden="true">
                      <use href="#brands-whatsapp" />
                    </svg>
                    {" WhatsApp"}
                  </a>
                  <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Commercial%20Auto&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Commercial%20Auto.%0A%0AName%3A%0APhone%3A%0A"}>
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-envelope" />
                    </svg>
                    {" Email"}
                  </a>
                </div>
              </article>
              <article className="card sc rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-helmet-safety" />
                  </svg>
                </div>
                <h3>
                  <Link to="/workers-compensation.html">
                    Workers’ Compensation
                  </Link>
                </h3>
                <p>
                  Medical and wage benefits for injured employees.
                </p>
                <div className="act">
                  <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Workers%E2%80%99%20Compensation" target="_blank" rel="noopener">
                    <svg className="i" aria-hidden="true">
                      <use href="#brands-whatsapp" />
                    </svg>
                    {" WhatsApp"}
                  </a>
                  <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Workers%E2%80%99%20Compensation&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Workers%E2%80%99%20Compensation.%0A%0AName%3A%0APhone%3A%0A"}>
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-envelope" />
                    </svg>
                    {" Email"}
                  </a>
                </div>
              </article>
              <article className="card sc rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-briefcase" />
                  </svg>
                </div>
                <h3>
                  <Link to="/professional-liability.html">
                    Professional Liability (E&amp;O)
                  </Link>
                </h3>
                <p>
                  Protection against claims of mistakes in your work.
                </p>
                <div className="act">
                  <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Professional%20Liability%20%28E%26O%29" target="_blank" rel="noopener">
                    <svg className="i" aria-hidden="true">
                      <use href="#brands-whatsapp" />
                    </svg>
                    {" WhatsApp"}
                  </a>
                  <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Professional%20Liability%20%28E%26O%29&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Professional%20Liability%20%28E%26O%29.%0A%0AName%3A%0APhone%3A%0A"}>
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-envelope" />
                    </svg>
                    {" Email"}
                  </a>
                </div>
              </article>
            </div>
          </div>
        </section>
        <script type="application/ld+json" dangerouslySetInnerHTML={{__html:"{\"@context\":\"https://schema.org\",\"@type\":\"FAQPage\",\"mainEntity\":[{\"@type\":\"Question\",\"name\":\"What does General Liability cover?\",\"acceptedAnswer\":{\"@type\":\"Answer\",\"text\":\"Typical coverage includes: customer injury claims; damage to other people’s property; advertising injury; legal defense costs. Exact terms depend on the provider and the plan you choose.\"}},{\"@type\":\"Question\",\"name\":\"Who needs General Liability?\",\"acceptedAnswer\":{\"@type\":\"Answer\",\"text\":\"Almost any business that deals with customers or works on client sites.\"}},{\"@type\":\"Question\",\"name\":\"How do I get a quote?\",\"acceptedAnswer\":{\"@type\":\"Answer\",\"text\":\"Select Get a quote, choose General Liability and send your details. One of our partners will contact you with options.\"}},{\"@type\":\"Question\",\"name\":\"Does it cost anything to request a quote?\",\"acceptedAnswer\":{\"@type\":\"Answer\",\"text\":\"No. Requesting a quote through Loadhub Marketing is free and does not oblige you to buy.\"}},{\"@type\":\"Question\",\"name\":\"Is Loadhub Marketing the provider?\",\"acceptedAnswer\":{\"@type\":\"Answer\",\"text\":\"No. We are a lead generation company. Independent partners make the offers and provide the service.\"}}]}"}} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{__html:"{\"@context\":\"https://schema.org\",\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"Home\",\"item\":\"https://loadhubmarketing.com/\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"Business\",\"item\":\"https://loadhubmarketing.com/services.html#business\"},{\"@type\":\"ListItem\",\"position\":3,\"name\":\"General Liability\",\"item\":\"https://loadhubmarketing.com/general-liability.html\"}]}"}} />
      </main>
  )
}
