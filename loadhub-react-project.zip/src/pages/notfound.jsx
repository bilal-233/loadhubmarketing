import { Link } from 'react-router-dom'

export const head = {
  "title": "Page not found | Loadhub Marketing",
  "tags": [
    {
      "name": "description",
      "content": "This page could not be found."
    },
    {
      "name": "robots",
      "content": "noindex,follow"
    },
    {
      "property": "og:type",
      "content": "website"
    },
    {
      "property": "og:title",
      "content": "Page not found | Loadhub Marketing"
    },
    {
      "property": "og:description",
      "content": "This page could not be found."
    },
    {
      "property": "og:url",
      "content": "https://loadhubmarketing.com/404.html"
    },
    {
      "property": "og:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    },
    {
      "property": "og:image:width",
      "content": "1200"
    },
    {
      "property": "og:image:height",
      "content": "630"
    },
    {
      "property": "og:image:alt",
      "content": "Loadhub Marketing, insurance lead generation"
    },
    {
      "property": "og:site_name",
      "content": "Loadhub Marketing"
    },
    {
      "property": "og:locale",
      "content": "en_US"
    },
    {
      "name": "twitter:card",
      "content": "summary_large_image"
    },
    {
      "name": "twitter:title",
      "content": "Page not found | Loadhub Marketing"
    },
    {
      "name": "twitter:description",
      "content": "This page could not be found."
    },
    {
      "name": "twitter:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    }
  ]
}

export default function Notfound() {
  return (
    <main>
        <section className="phead">
          <div className="wrap" style={{textAlign:"center"}}>
            <h1 className="nm" style={{fontSize:"clamp(2rem,4.5vw,3.2rem)"}}>
              {"Page "}
              <span>
                not found
              </span>
            </h1>
            <p className="lead" style={{margin:"14px auto 22px"}}>
              The page you are looking for is not here. Try the home page or tell us what you need.
            </p>
            <Link to="/" className="btn p">
              Go to home
            </Link>
            {" "}
            <Link to="/contact.html" className="btn o">
              Contact us
            </Link>
          </div>
        </section>
      </main>
  )
}
