# Loadhub Marketing (React + Vite)

Same site as before, now a React app. Every page is pre-rendered to real HTML at build time (good for Google and link previews).

## Run locally
    npm install
    npm run dev        # development
    npm run build      # production build into dist/
    npm run preview    # preview the build

## Deploy on Vercel
Push this folder to GitHub, then Vercel -> Add New Project -> pick the repo. Settings are in vercel.json (Vite, output: dist). Nothing else to set.

## Where things are
- src/pages/*.jsx   one file per page (home.jsx = index, notfound.jsx = 404)
- src/components/   Header, Footer, Chatbot, Layout
- src/styles.css    all CSS
- public/config.js  put your Web3Forms access key here (formKey)
- public/           images, favicons, robots.txt, sitemap.xml
