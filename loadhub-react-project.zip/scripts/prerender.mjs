// Renders every page to static HTML so Google, social previews and slow phones get real content.
import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'

const dist = path.resolve('dist')
const template = fs.readFileSync(path.join(dist, 'index.html'), 'utf8')
const { render, routes } = await import(pathToFileURL(path.resolve('dist-ssr/entry-server.js')).href)

for (const r of routes) {
  const html = template
    .replace('<!--head-tags-->', r.head)
    .replace('<!--app-html-->', render(r.url))
  fs.writeFileSync(path.join(dist, r.file), html)
  console.log('prerendered', r.file)
}
fs.rmSync(path.resolve('dist-ssr'), { recursive: true, force: true })
